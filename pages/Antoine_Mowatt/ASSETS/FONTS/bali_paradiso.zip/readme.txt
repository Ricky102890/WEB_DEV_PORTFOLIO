Hello,

Thank for downloading Bali Paradiso.


NOTE: This demo font is for PERSONAL USE ONLY!
But any donation are very appreciated. 

Paypal account for donation : creativework69@yahoo.com 
commercial Lisense : www.fontbundle/creativework69/bali paradiso

Thanks,

creativework studio